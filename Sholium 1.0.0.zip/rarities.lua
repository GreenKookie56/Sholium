SMODS.Rarity {
    key = "the_expert",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.005,
    badge_colour = HEX('7e7e3a'),
    loc_txt = {
        name = "The Expert"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}
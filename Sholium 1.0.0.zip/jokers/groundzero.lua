SMODS.Joker{ --Ground Zero
    name = "Ground Zero",
    key = "groundzero",
    config = {
        extra = {
            Active = 1,
            chips = 350
        }
    },
    loc_txt = {
        ['name'] = 'Ground Zero',
        ['text'] = {
            [1] = '{C:blue}+#2#{} Chips for the first hand of the round',
            [2] = '{C:gold}this looks familiar...{}',
            [3] = '{C:inactive}Art Design by Gabe Owser{}'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Active, card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
            if (card.ability.extra.Active or 0) == 1 then
                card.ability.extra.Active = 0
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.Active = 1
                    return true
                end
                }
        end
    end
}
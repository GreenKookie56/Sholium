SMODS.Joker{ --First ever Exactly 2mpc
    name = "First ever Exactly 2mpc",
    key = "firste2m",
    config = {
        extra = {
            mult = 2000000,
            req = 38,
            played = 0
        }
    },
    loc_txt = {
        ['name'] = 'First ever Exactly 2mpc',
        ['text'] = {
            [1] = '{C:red}+#1#{} Mult after playing {C:attention}38{} hands',
            [2] = '{C:inactive}(#3#/#2#){}'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult, card.ability.extra.req, card.ability.extra.played}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
            if (card.ability.extra.played or 0) >= card.ability.extra.req then
                return {
                    mult = card.ability.extra.mult
                }
            else
                card.ability.extra.played = (card.ability.extra.played) + 1
                return {
                    message = "Update!"
                }
            end
        end
    end
}
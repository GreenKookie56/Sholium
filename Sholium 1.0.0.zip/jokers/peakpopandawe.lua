SMODS.Joker{ --Peak Pop and Awe
    name = "Peak Pop and Awe",
    key = "peakpopandawe",
    config = {
        extra = {
            chips = -8,
            xchips = 4
        }
    },
    loc_txt = {
        ['name'] = 'Peak Pop and Awe',
        ['text'] = {
            [1] = '{C:blue}-8{} Chips, then {X:blue,C:white}X4{} Chips'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        x_chips = card.ability.extra.xchips,
                        colour = G.C.DARK_EDITION
                        }
                }
        end
    end
}
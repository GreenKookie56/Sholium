SMODS.Joker{ --Bugged Orca
    name = "Bugged Orca",
    key = "buggedorca",
    config = {
        extra = {
            patch = 1,
            mult = 16.5,
            dead = 0,
            odds = 36
        }
    },
    loc_txt = {
        ['name'] = 'Bugged Orca',
        ['text'] = {
            [1] = '{X:red,C:white}X16.5{} Mult',
            [2] = '{C:green}1 in 36{} chance to set to {X:red,C:white}X#1#{} Mult',
            [3] = 'when a {C:attention}played card{} is {C:attention}scored{}'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {G.GAME.probabilities.normal}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    Xmult = card.ability.extra.mult
                }
        end
        if context.individual and context.cardarea == G.play and not context.blueprint then
            if (card.ability.extra.dead or 0) == 0 then
                if SMODS.pseudorandom_probability(card, 'group_0_c10bcebc', 1, card.ability.extra.odds, 'group_0_c10bcebc') then
                        card.ability.extra.dead = 1
                        card.ability.extra.mult = card.ability.extra.patch
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Patched!", colour = G.C.BLUE})
                    end
            end
        end
    end
}
SMODS.Joker{ --Release Geraldo
    name = "Release Geraldo",
    key = "releasegeraldo",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Release Geraldo',
        ['text'] = {
            [1] = 'Create a random {C:attention}Tag{} per {C:green}reroll{}',
            [2] = '{C:inactive}Ah yes common{}'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.reroll_shop and not context.blueprint then
                return {
                    func = function()
            G.E_MANAGER:add_event(Event({
                func = function()
                    local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                    local tag = Tag(selected_tag)
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
                    return true
                end,
                    message = "heaps of dev and balance time"
                }
        end
    end
}
SMODS.Joker{ --Pudding Egg
    name = "Pudding Egg",
    key = "puddingegg",
    config = {
        extra = {
            BossDefeat = 0,
            joker_slots = 100,
            joker_slots2 = 100,
            j_sholium_thepudding = 0
        }
    },
    loc_txt = {
        ['name'] = 'Pudding Egg',
        ['text'] = {
            [1] = 'After {C:attention}3{} Antes, {C:red}self destructs{}',
            [2] = 'and create {C:dark_edition}The Pudding{}',
            [3] = '{C:inactive}(Currently #1#/3){}'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.BossDefeat}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss and not context.blueprint then
            if (card.ability.extra.BossDefeat or 0) >= 2 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!",
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "create...", colour = G.C.DARK_EDITION})
                G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.joker_slots
                return true
            end,
                        colour = G.C.DARK_EDITION,
                        extra = {
                            func = function()
            local created_joker = false
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    created_joker = true
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local joker_card = create_card('Joker', G.jokers, nil, nil, nil, nil, 'j_sholium_thepudding')
                            joker_card:add_to_deck()
                            G.jokers:emplace(joker_card)
                            G.GAME.joker_buffer = 0
                            return true
                        end
                    }))
                end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end,
                            colour = G.C.BLUE,
                        extra = {
                            func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "complete!", colour = G.C.RED})
                G.jokers.config.card_limit = math.max(1, G.jokers.config.card_limit - card.ability.extra.joker_slots2)
                return true
            end,
                            colour = G.C.DARK_EDITION
                        }
                        }
                        }
                }
            else
                return {
                    func = function()
                    card.ability.extra.BossDefeat = (card.ability.extra.BossDefeat) + 1
                    return true
                end,
                    message = "Upgrade!"
                }
            end
        end
    end
}
SMODS.Joker{ --The Pudding
    name = "The Pudding",
    key = "thepudding",
    config = {
        extra = {
            PuddingMult = 4,
            PuddingMultScale = 1
        }
    },
    loc_txt = {
        ['name'] = 'The Pudding',
        ['text'] = {
            [1] = '{X:dark_edition,C:white}^#1#{} Mult',
            [2] = 'Increase by {X:dark_edition,C:white}^#2#{} when each',
            [3] = 'played {C:attention}7{} of {C:clubs}Club{} is scored',
            [4] = '{C:inactive}Card does NOT change{}'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    cost = 17,
    rarity = "sholium_the_expert",
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.PuddingMult, card.ability.extra.PuddingMultScale}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    e_mult = card.ability.extra.PuddingMult
                }
        end
        if context.individual and context.cardarea == G.play and not context.blueprint then
            if (context.other_card:get_id() == 7 and context.other_card:is_suit("Clubs")) then
                card.ability.extra.PuddingMult = (card.ability.extra.PuddingMult) + card.ability.extra.PuddingMultScale
                return {
                    message = "Upgrade!"
                }
            end
        end
    end
}
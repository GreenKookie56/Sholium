SMODS.Joker{ --Release Rosalia
    name = "Release Rosalia",
    key = "releaserosalia",
    config = {
        extra = {
            chips = 43
        }
    },
    loc_txt = {
        ['name'] = 'Release Rosalia',
        ['text'] = {
            [1] = '{C:blue}+43{} Chips'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}
SMODS.Joker{ --Release Corvus
    name = "Release Corvus",
    key = "releasecorvus",
    config = {
        extra = {
            Remaining = 2,
            chips = 8000
        }
    },
    loc_txt = {
        ['name'] = 'Release Corvus',
        ['text'] = {
            [1] = '{C:blue}+#2#{} Chips every {C:attention}3{} hands played',
            [2] = '{C:inactive}#1# remaining{}'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 1,
        y = 1
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Remaining, card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
            if (card.ability.extra.Remaining or 0) <= 0 then
                card.ability.extra.Remaining = 2
                return {
                    chips = card.ability.extra.chips
                }
            else
                card.ability.extra.Remaining = math.max(0, (card.ability.extra.Remaining) - 1)
            end
        end
    end
}